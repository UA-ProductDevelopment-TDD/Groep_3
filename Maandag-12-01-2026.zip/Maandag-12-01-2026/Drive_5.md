# Drive_5
Note: You may add a short description/instruction here.

Model: Bittle

Creator: Nature

Location: Earth

Date: Jan 11, 2026

# [Demo](www.youtube.com) You can modify the link in the round brackets

# Token
K

# Data
{
  -3,   0,   0,   1,
   0,   0,   0,
 -30, -80, -45,   0,  -3,  -3,   3,   3,  60,  60,  99,  99, -34, -34, -27, -27,   8,   0,   0,   0,
 -30, -80, -45,   0,  -3,  -3,   3,   3,  60,  60,  99,  99, -34, -34, -27, -27,   8,   0,   0,   0,
 -30, -80, -45,   0,  -3,  -3,   3,   3,  60,  60,  99,  99, -34, -34, -27, -27,   8,   0,   0,   0,
};